<!--Jquery-->
<script src="assets/js/jquery-3.5.0.min.js"></script>
<!--Bootstrap Js-->
<script src="assets/js/bootstrap.bundle.min.js"></script>

<!--Main Js-->
<script src="assets/js/main.js"></script>
<!-- Custom JS -->
<script src="assets/js/custom.js"></script>

</body>

</html>