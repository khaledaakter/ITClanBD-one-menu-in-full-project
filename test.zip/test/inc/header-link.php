<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="HTML5,CSS3,SASS,Bootstrap,JavaScript,Jquery">
    <meta name="author" content="ITCLAN BD" />
    <title>Clan Dash</title>
    <!-- Favicon -->
    <link rel="icon" href="assets/images/logo/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!--Icons-->
    <link rel="stylesheet" href="assets/css/icons/remixicon/remixicon.css">
    <!--Main CSS-->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>