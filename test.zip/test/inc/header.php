<?php include 'inc/header-link.php' ?>

<div id="app">
    <div class="main-wrapper main-wrapper-1">

        <!--===Header Top Start===-->

        <nav class="ic-header sticky">
            <div class="ic-header-top-warper">
                <!-- Header Search Form start -->
                <div class="ic-top-header-left">
                    <div class="ic-mobile-logo">
                        <img src="assets/images/logo/logo-mini.png" class="img-fluid" alt="logo">
                    </div>
                    <a href="#" class="ic-mobile-nav-collapse">
                        <span></span>
                        <span></span>
                        <span></span>
                    </a>
                    <a href="javascript:void(0)" class="ic-sidebar-cancel"><i class="ri-close-fill"></i></a>
                    <form class="ic-header-form">
                        <a href="#" class="search-icon"><i class="ri-search-line"></i></a>
                        <input type="text" class="form-control" placeholder="Search here" />
                    </form>
                </div>
                <!-- Header Search Form end -->

                <!-- All Header Icons start -->
                <div class="ic-header-top-right">
                    <!-- Full screen Icon -->
                    <div class="ic-header-icons">
                        <div class="nav-icons">
                            <a href="#" class="ic-header-icon" id="btnFullscreen">
                                <i class="ri-fullscreen-line"></i>
                            </a>
                        </div>
                        <!-- Notification Icon -->
                        <div class="nav-icons  ic-header-notification">
                            <a href="#" class="ic-header-icon">
                                <i class="ri-notification-2-fill"></i>
                                <p class="ic-bg-pink">12</p>
                            </a>
                            <!-- Notification dropdown -->
                            <ul class="ic-header-notification-options">
                                <li class="ic-header-notifications-header">Notifications</li>
                                <li class="ic-header-notifications-items">
                                    <div class="ic-header-notifications-items--item">
                                        <img src="/assets/images/header/n-profile.png" alt="profile" />
                                        <div class="ic-header-notificatin-details">
                                            <h4>Socrates Itumay</h4>
                                            <h5>nam libreo tepore cum so..</h5>
                                            <h6>Mar 15 12:32pm</h6>
                                        </div>
                                    </div>
                                    <div class="ic-header-notifications-items--item">
                                        <img src="/assets/images/header/n-profile.png" alt="profile" />
                                        <div class="ic-header-notificatin-details">
                                            <h4>Socrates Itumay</h4>
                                            <h5>nam libreo tepore cum so..</h5>
                                            <h6>Mar 15 12:32pm</h6>
                                        </div>
                                    </div>
                                    <div class="ic-header-notifications-items--item">
                                        <img src="/assets/images/header/n-profile.png" alt="profile" />
                                        <div class="ic-header-notificatin-details">
                                            <h4>Socrates Itumay</h4>
                                            <h5>nam libreo tepore cum so..</h5>
                                            <h6>Mar 15 12:32pm</h6>
                                        </div>
                                    </div>
                                </li>
                                <li class="ic-header-notifications-footer">View All Notifications</li>
                            </ul>
                        </div>
                        <!-- Gift Icon -->
                        <div class="nav-icons">
                            <a href="#" class="ic-header-icon">
                                <i class="ri-gift-2-fill"></i>
                                <p class="ic-bg-blue">5</p>
                            </a>
                        </div>
                        <!-- Check Icon -->
                        <div class="nav-icons">
                            <a href="#" class="ic-header-icon me-0">
                                <i class="ri-chat-check-fill"></i>
                                <p class="ic-bg-green">2</p>
                            </a>
                        </div>
                    </div>
                    <!-- All Header Icons end -->

                    <!-- Header Language start -->
                    <div class="nav-item ic-header-language">
                        <div class="ic-header-language-details ">
                            <img src="assets/images/header/english.jpg" alt="state" />
                            <p>english</p>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                        <!-- Language Dropdown -->
                        <div class="ic-language-options">
                            <a href="#">
                                <img src="assets/images/header/italy.jpg" alt="state" />
                                <p>ITALY</p>
                            </a>
                            <a href="#">
                                <img src="assets/images/header/france.jpg" alt="state" />
                                <p>FRANCE</p>
                            </a>
                            <a href="#">
                                <img src="assets/images/header/german.jpg" alt="state" />
                                <p>GERMAN</p>
                            </a>
                        </div>
                    </div>

                    <!-- Header Language end -->

                    <!-- Header Profile start -->
                    <div class="ic-header-profile nav-item">
                        <img src="assets/images/logo/profile.jpg" alt="profile" />
                        <div class="ic-header-profile-details">
                            <h6>Ralph Edwards</h6>
                            <p>Super Admin</p>
                        </div>
                        <i class="fas fa-chevron-down"></i>
                        <!-- Profile Dropdown -->
                        <div class="ic-header-profile--options">
                            <a href="#">
                                <i class="ri-user-line"></i>
                                <p>Profile</p>
                            </a>
                            <a href="#">
                                <i class="ri-settings-5-line"></i>
                                <p>settings</p>
                            </a>
                            <a href="#">
                                <i class="ri-questionnaire-line"></i>
                                <p>FAQ</p>
                            </a>
                            <a href="#">
                                <i class="ri-logout-box-r-line"></i>
                                <p>Logout</p>
                            </a>
                        </div>
                    </div>
                    <!-- Header Profile end -->
                </div>
            </div>
            <div class="ic-mobile-header-bottom">
                <a href="javascript:void(0)" class="ic-mobile-nav-collapse">
                    <span></span>
                    <span></span>
                    <span></span>
                </a>
                <div class="ic-top-header-left">
                    <form class="ic-header-form">
                        <a href="#" class="search-icon"><i class="ri-search-line"></i></a>
                        <input type="text" class="form-control" placeholder="Search here">
                    </form>
                </div>
                <div class="ic-header-top-right">
                    <div class="nav-item ic-header-language">
                        <div class="ic-header-language-details ">
                            <img src="assets/images/header/english.jpg" alt="state">
                            <p>english</p>
                            <i class="fas fa-chevron-down"></i>
                        </div>
                        <!-- Language Dropdown -->
                        <div class="ic-language-options">
                            <a href="#">
                                <img src="assets/images/header/italy.jpg" alt="state">
                                <p>ITALY</p>
                            </a>
                            <a href="#">
                                <img src="assets/images/header/france.jpg" alt="state">
                                <p>FRANCE</p>
                            </a>
                            <a href="#">
                                <img src="assets/images/header/german.jpg" alt="state">
                                <p>GERMAN</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>


        </nav>
        <!--===Header Top Area End===-->

        <!--===Sidebar Area Start===-->

        <div class="main-sidebar sidebar-style-2">
            <aside id="sidebar-wrapper">
                <div class="sidebar-brand">
                    <a href="index.php">
                        <img alt="image" src="assets/images/logo/logo.png" class="img-fluid large-logo"
                            class="header-logo" />
                        <img src="assets/images/logo/logo-mini.png" class="img-fluid mini-logo" alt="logo">
                    </a>
                    <a href="#" class="ic-nav-collapse">
                        <span></span>
                        <span></span>
                        <span></span>
                    </a>
                    <div class="ic-mobile-sidebar-close">
                        <a href="#"><i class="ri-close-circle-line"></i></a>
                    </div>
                </div>
                <ul class="sidebar-menu ic-navbar-nav">
                    <div class="ic-menu-title">
                        <h6>Main Menu</h6>
                    </div>
                    <li class="ic-nav-item active">
                        <a href="index.php" class="nav-link">
                            <i class="ri-home-2-fill"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="ic-nav-item">
                        <a href="email.php" class="nav-link">
                            <i class="ri-mail-open-fill"></i>
                            <span>Email</span>
                            <span class="ic-nav-badge">17</span>
                        </a>
                    </li>
                    <li class="ic-nav-item">
                        <a href="index.php" class="nav-link">
                            <i class="ri-chat-3-fill"></i>
                            <span>Chat</span>
                        </a>
                    </li>
                    <li class="ic-nav-item">
                        <a href="index.php" class="nav-link">
                            <i class="ri-calendar-fill"></i>
                            <span>calender</span>
                        </a>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-account-circle-fill"></i>
                            <span>Authentication</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="login.php">Login</a>
                            </li>
                            <li>
                                <a class="nav-link" href="#">Register</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-archive-fill"></i>
                            <span>Tasks</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="#">Taskes</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-pages-fill"></i>
                            <span>Pages</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="#">Pages</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-shopping-cart-2-fill"></i>
                            <span>e-commerce</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="#">e-commerce</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-clipboard-fill"></i>
                            <span>Components</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="general.php">General</a>
                            </li>
                            <li>
                                <a class="nav-link" href="grids.php">Grids</a>
                            </li>
                            <li>
                                <a class="nav-link" href="alerts.php">Alerts</a>
                            </li>
                            <li>
                                <a class="nav-link" href="button.php">Buttons</a>
                            </li>
                            <li>
                                <a class="nav-link" href="card.php">Cards</a>
                            </li>
                            <li>
                                <a class="nav-link" href="carousel.php">Carousel</a>
                            </li>
                            <li>
                                <a class="nav-link" href="dropdown.php">Dropdowns</a>
                            </li>
                            <li>
                                <a class="nav-link" href="modal.php">Modals</a>
                            </li>
                            <li>
                                <a class="nav-link" href="progress.php">Progress Bars
                                </a>
                            </li>
                            <li>
                                <a class="nav-link" href="tab.php">Tabs & Accordions
                                </a>
                            </li>
                            <li>
                                <a class="nav-link" href="typography.php">Typography
                                </a>
                            </li>
                            <li>
                                <a class="nav-link" href="images.php">Images</a>
                            </li>
                            <li>
                                <a class="nav-link" href="video.php">Video</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-briefcase-4-fill"></i>
                            <span>Extended</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="#">Extended</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-file-list-3-fill"></i>
                            <span>Forms</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="forms-element.php">Basic Elements</a>
                            </li>
                            <li>
                                <a class="nav-link" href="file-upload.php">File Upload</a>
                            </li>
                            <li>
                                <a class="nav-link" href="forms-validation.php">Validation</a>
                                <a class="nav-link" href="form-wizard.php">Wizard</a>
                            </li>
                            <li>
                                <a class="nav-link" href="editor.php">Editor</a>
                            </li>
                            <li>
                                <a class="nav-link" href="mask.php">Mask</a>
                            </li>
                            <li>
                                <a class="nav-link" href="advance-form.php">Form Advance</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-table-fill"></i>
                            <span>Tables</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="#">Tables</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-pie-chart-fill"></i>
                            <span>Charts</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="apexchart.php">Apex Charts </a>
                            </li>
                            <li>
                                <a class="nav-link" href="echart.php">E Chart </a>
                            </li>
                            <li>
                                <a class="nav-link" href="chartjs.php">ChartJs Chart</a>
                            </li>
                            <li>
                                <a class="nav-link" href="jquerykonb.php">Jquery Knob Chart</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-map-2-fill"></i>
                            <span>Maps</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="#">Maps</a>
                            </li>
                        </ul>
                    </li>
                    <li class="ic-nav-item ic-dropdown-has-children">
                        <a href="#" class="nav-link menu-expand">
                            <i class="ri-settings-2-fill"></i>
                            <span>Setting</span>
                        </a>
                        <ul class="ic-dropdown-sub-menu">
                            <li>
                                <a class="nav-link" href="#">Setting</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <div class="ic-sidebar-banner"
                    style="background-image: url('assets/images/logo/sidebar-banner-bg.png');">
                    <div class="ic-content text-center">
                        <h3 class="ic-mb-40">Boost Your
                            Work Speed
                            With</h3>
                        <img src="assets/images/logo/logo-sidebar.png" class="img-fluid" alt="logo">
                    </div>
                </div>
                <div class="ic-sidebar-copyright">
                    <div class="copyright-txt">
                        <p>© 2021 <a href="#">Clan<span>Dash</span></a>. All Rights Reserved.</p>
                        <p class="ic-p2">Design & Developed with <i class="ri-heart-fill"></i> By <a
                                href="#">ITclan.</a> </p>
                    </div>
                </div>
            </aside>
        </div>

        <!--===Sidebar Area End===-->