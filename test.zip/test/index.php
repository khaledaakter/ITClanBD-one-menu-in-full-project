<?php include 'inc/header.php'   ?>

<!--===Main Content Start===-->

<!--===Main Content End===-->

<?php include 'inc/footer.php'   ?>