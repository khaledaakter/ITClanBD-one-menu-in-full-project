// ck editor
// ClassicEditor.create(document.querySelector("#ckeditor-classic")).then(function(e){
//     e.ui.view.editable.element.style.height="200px"
// }).catch(function(e){console.error(e)});

if ($('#ckeditor-classic').length > 0) {
    ClassicEditor
    .create( document.querySelector( '#ckeditor-classic' ) )
    .then(function(e){
        e.ui.view.editable.element.style.height="200px"
    })
    .catch( error => {
        console.error( error );
    } );
}

