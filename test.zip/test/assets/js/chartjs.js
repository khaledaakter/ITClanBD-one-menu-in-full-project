!(function ($) {
  "use strict";
  // line Chart
  if ($("#ic-line-chart").length > 0) {
    const icLineChart = document.getElementById("ic-line-chart");
    const yValue = [12, 52, 36, 21, 52, 32, 14, 51, 21, 24, 23, 26];
    const icMyChart = new Chart(icLineChart, {
      type: "line",
      data: {
        labels: [
          "January",
          "February",
          "March",
          "April",
          "May",
          "June",
          "July",
          "August",
          "September",
          "October",
        ],
        datasets: [
          {
            label: "Salary",
            backgroundColor: "rgb(59, 197, 196, 0.1)",
            borderColor: "rgb(59, 197, 196, 1)",
            data: yValue,
          },
        ],
      },
      options: {
        responsive: true,
        interaction: {
          mode: "index",
          intersect: false,
        },
        stacked: false,
        plugins: {
          title: {
            display: true,
            text: "Chart.js Line Chart - Multi Axis",
          },
        },
        scales: {
          y: {
            type: "linear",
            display: true,
            position: "left",
          },
          y1: {
            type: "linear",
            display: true,
            position: "right",

            // grid line settings
            grid: {
              drawOnChartArea: false, // only want the grid lines for one axis to show up
            },
          },
        },
      },
    });
  }
  // multi line chart

  if ($("#ic-multiLine-chart").length > 0) {
    const icMultiLineChart = document.getElementById("ic-multiLine-chart");
    // chart data
    const xValues = [100, 200, 300, 400, 500, 600, 700, 800, 900, 1000];
    const icMultiChart = new Chart(icMultiLineChart, {
      type: "line",
      data: {
        labels: xValues,
        datasets: [
          {
            label: "Present",
            data: [860, 1140, 1060, 1060, 1070, 1110, 1330, 2210, 7830, 2478],
            borderColor: "#18B87A",
            fill: false,
          },
          {
            label: "Absent",
            data: [1600, 1700, 1700, 1900, 2000, 2700, 4000, 5000, 6000, 7000],
            borderColor: "#FF5C66",
            fill: false,
          },
          {
            label: "Late",
            data: [300, 700, 2000, 5000, 6000, 4000, 2000, 1000, 200, 100],
            borderColor: "#F7AB02",
            fill: false,
          },
        ],
      },
    });
  }

  // bar chart

  if ($("#ic-bar-chart").length > 0) {
    const icBarChart = document.getElementById("ic-bar-chart");
    const xValue = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
    ];
    const yValue = [55, 49, 44, 24, 16, 50, 80, 30, 24, 50];
    const borderColor = ["#FF5C66"];
    const icBarChartInit = new Chart(icBarChart, {
      type: "bar",
      data: {
        labels: xValue,
        datasets: [
          {
            backgroundColor: borderColor,
            data: yValue,
          },
        ],
      },
    });
  }

  // pie chart

  if ($("#ic-Pie-chart").length > 0) {
    const icPieChart = document.getElementById("ic-Pie-chart");
    const icPieChartInit = new Chart(icPieChart, {
      type: "pie",
      data: {
        labels: ["Desktops", "Tablets"],
        datasets: [
          {
            data: [300, 180],
            backgroundColor: ["#25ACAB", "#3BC5C4"],
            hoverBorderColor: "#fff",
          },
        ],
      },
    });
  }
  // doughnut
  if ($("#ic-doughnut-chart").length > 0) {
    const icPieChart = document.getElementById("ic-doughnut-chart");
    const icPieChartInit = new Chart(icPieChart, {
      type: "doughnut",
      data: {
        labels: ["Desktops", "Tablets"],
        datasets: [
          {
            data: [300, 180],
            backgroundColor: ["#FFBF2E", "#FF5C66"],
            hoverBorderColor: "#fff",
          },
        ],
      },
    });
  }

  // polarArea
  if ($("#ic-Polar-chart").length > 0) {
    const icPieChart = document.getElementById("ic-Polar-chart");
    const icPieChartInit = new Chart(icPieChart, {
      type: "polarArea",
      data: {
        labels: ["Serise 1", "Serise 2", "Serise 3"],
        datasets: [
          {
            data: [300, 180, 70, 100, 150, 100],
            backgroundColor: ["#FFBF2E", "#FF5C66", "#25ACAB"],
            hoverBorderColor: "#fff",
          },
        ],
      },
    });
  }
})(jQuery);
