// select js
document.addEventListener("DOMContentLoaded", function() {
    var e = document.querySelectorAll("[data-trigger]");
    for (i = 0; i < e.length; ++i) {
        var a = e[i];
        new Choices(a, {
            placeholderValue: "This is a placeholder set in the config",
            searchPlaceholderValue: "This is a search placeholder"
        })
    }
    if ($('.choices-multiple-remove-button').length > 0) {
        new Choices(".choices-multiple-remove-button", {
            delimiter: ",",
            editItems: !0,
            maxItemCount: 5,
            searchEnabled: true,
            removeItemButton: true,
            duplicateItemsAllowed: true
        })
    }
    if ($('.allchoices-multiple-remove-button').length > 0) {
        new Choices(".allchoices-multiple-remove-button", {
            delimiter: ",",
            editItems: !0,
            maxItemCount: 5,
            searchEnabled: true,
            removeItemButton: true,
            duplicateItemsAllowed: true
        })
    }
    if ($('.addchoices-multiple-remove-button').length > 0) {
        new Choices(".addchoices-multiple-remove-button", {
            delimiter: ",",
            editItems: !0,
            maxItemCount: 5,
            searchEnabled: true,
            removeItemButton: true,
            duplicateItemsAllowed: true
        })
    }
    if ($('.choices-text-remove-button').length > 0) {
        new Choices(".choices-text-remove-button", {
            removeItemButton: !0
        })
    }
    if ($('.choices-single-default').length > 0) {
        new Choices(".choices-single-default", {
            searchEnabled: !1,
            duplicateItemsAllowed: true
        })
    }
});

// range slider js


var nonLinearSlider = document.getElementById("nonlinear");
noUiSlider.create(nonLinearSlider, {
    connect: !0,
    behaviour: "tap",
    start: [500, 4e3],
    range: {
        min: [0],
        "10%": [500, 500],
        "50%": [4e3, 1e3],
        max: [1e4]
    }
});










// flatpicker js

flatpickr("#datepicker-basic", {
    defaultDate: new Date
}), flatpickr("#datepicker-datetime", {
    enableTime: !0,
    dateFormat: "m-d-Y H:i",
    defaultDate: new Date
}), flatpickr("#datepicker-humanfd", {
    altInput: !0,
    altFormat: "F j, Y",
    dateFormat: "Y-m-d",
    defaultDate: new Date
}), flatpickr("#datepicker-minmax", {
    minDate: "today",
    defaultDate: new Date,
    maxDate: (new Date).fp_incr(14)
}), flatpickr("#datepicker-disable", {
    onReady: function() {
        this.jumpToDate("2025-01")
    },
    disable: ["2025-01-30", "2025-02-21", "2025-03-08", new Date(2025, 4, 9)],
    dateFormat: "Y-m-d",
    defaultDate: new Date
}), flatpickr("#datepicker-multiple", {
    mode: "multiple",
    dateFormat: "Y-m-d",
    defaultDate: new Date,
}), flatpickr("#datepicker-range", {
    mode: "range",
    defaultDate: new Date
}), flatpickr("#datepicker-timepicker", {
    enableTime: !0,
    noCalendar: !0,
    dateFormat: "H:i",
    defaultDate: new Date
})

