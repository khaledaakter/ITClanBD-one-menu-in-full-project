let icAlertPlaceHolder = document.getElementById('icLiveAlertPlaceholder');
let icLiveAlertBtn = document.getElementById('icLiveAlertBtn');
const  alert = (e, t) => {
    let I = document.createElement('div');
    I.innerHTML = '<div class="alert alert-' + t + ' alert-dismissible" role="alert">' + e + '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>',
        icAlertPlaceHolder.append(I);
}
if (icLiveAlertBtn) {
    icLiveAlertBtn.addEventListener('click', function () {
    alert("Nice, you triggered this alert message!", "primary");
});
}
