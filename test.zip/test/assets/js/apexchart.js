!(function ($) {
  "use strict";

  if ($("#lineWithDataLabels").length) {
    let lineWithDataLabels = {
      series: [
        {
          name: "2019",
          data: [28, 29, 33, 36, 32, 32, 33, 20, 30, 10, 30, 22],
        },
        {
          name: "2020",
          data: [12, 11, 14, 18, 17, 13, 13, 33, 22, 21, 33, 11],
        },
        {
          name: "2021",
          data: [13, 21, 13, 17, 18, 16, 15, 25, 20, 24, 13, 11],
        },
      ],
      chart: {
        height: 350,
        type: "line",
        toolbar: {
          show: !1,
        },
      },
      colors: ["#FF5C66", "#04D182", "#1890FF"],
      dataLabels: {
        enabled: !1,
      },
      stroke: {
        width: [1, 1, 1],
        curve: "straight",
      },
      title: {
        text: "as",
        align: "left",
      },
      grid: {
        borderColor: "#f1f1f1",
        row: {
          colors: ["transparent", "transparent"], // takes an array which will be repeated on columns
          opacity: 0.2,
        },
      },
      markers: {
        style: "inverted",
        size: 0,
      },
      xaxis: {
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Dec",
        ],
        labels: {
          style: {
            fontSize: "14px",
            colors: "#8A8888",
            fontFamily: "firaSans-regular",
          },
        },
      },
      yaxis: {
        labels: {
          style: {
            fontSize: "16px",
            colors: "#8A8888",
            fontFamily: "firaSans-regular",
          },
        },
        color: ["#FF5C66"],
        min: 5,
        max: 40,
      },
      legend: {
        fontFamily: "firaSans-regular",
        fontWeight: 500,
        fontSize: "16px",
        labels: {
          colors: ["#FF5C66", "#04D182", "#1890FF"],
          useSeriesColors: true,
        },
        position: "top",
        horizontalAlign: "right",
        floating: !0,
        offsetY: -40,
        offsetX: -5,
      },
    };

    var chart = new ApexCharts(
      document.querySelector("#lineWithDataLabels"),
      lineWithDataLabels
    );
    chart.render();
  }

  // line dashed

  if ($("#lineDashedColor").length > 0) {
    var lineDashedColor = {
      series: [
        {
          name: "Session Duration",
          data: [45, 52, 38, 24, 33, 26, 21, 20, 6, 8, 15, 10],
        },
        {
          name: "Page Views",
          data: [35, 41, 62, 42, 13, 18, 29, 37, 36, 51, 32, 35],
        },
        {
          name: "Total Visits",
          data: [87, 57, 74, 99, 75, 38, 62, 47, 82, 56, 45, 47],
        },
      ],
      chart: {
        height: 350,
        type: "line",
        zoom: {
          enabled: !1,
        },
        toolbar: {
          show: !1,
        },
      },
      dataLabels: {
        enabled: !1,
      },
      stroke: {
        width: [3, 4, 3],
        curve: "straight",
        dashArray: [0, 8, 3],
      },
      title: {
        text: "Page Statistics",
        align: "left",
      },
      markers: {
        size: 0,
        hover: {
          sizeOffset: 6,
        },
      },
      xaxis: {
        categories: [
          "01 Jan",
          "02 Jan",
          "03 Jan",
          "04 Jan",
          "05 Jan",
          "06 Jan",
          "07 Jan",
          "08 Jan",
          "09 Jan",
          "10 Jan",
          "11 Jan",
          "12 Jan",
        ],
      },
      tooltip: {
        y: [
          {
            title: {
              formatter: function (e) {
                return e + " (mins)";
              },
            },
          },
          {
            title: {
              formatter: function (e) {
                return e + " per session";
              },
            },
          },
          {
            title: {
              formatter: function (e) {
                return e;
              },
            },
          },
        ],
      },
      grid: {
        borderColor: "#f1f1f1",
      },
    };

    var chart = new ApexCharts(
      document.querySelector("#lineDashedColor"),
      lineDashedColor
    );
    chart.render();
  }

  //   Spline Area

  if ($("#splineArea").length > 0) {
    var splineArea = {
      series: [
        {
          name: "series1",
          data: [31, 40, 28, 51, 42, 109, 100],
        },
        {
          name: "series2",
          data: [11, 32, 45, 32, 34, 52, 41],
        },
      ],
      colors: ["#3BC5C4", "#3D42AA"],
      chart: {
        height: 350,
        type: "area",
        toolbar: {
          show: !1,
        },
      },
      dataLabels: {
        enabled: false,
      },
      stroke: {
        curve: "smooth",
      },
      xaxis: {
        type: "datetime",
        categories: [
          "2018-09-19T00:00:00.000Z",
          "2018-09-19T01:30:00.000Z",
          "2018-09-19T02:30:00.000Z",
          "2018-09-19T03:30:00.000Z",
          "2018-09-19T04:30:00.000Z",
          "2018-09-19T05:30:00.000Z",
          "2018-09-19T06:30:00.000Z",
        ],
      },
      tooltip: {
        x: {
          format: "dd/MM/yy HH:mm",
        },
      },
    };

    var chart = new ApexCharts(
      document.querySelector("#splineArea"),
      splineArea
    );
    chart.render();
  }

  //  column Chart
  if ($("#column_chart").length > 0) {
    var options = {
      chart: {
        height: 350,
        type: "bar",
        toolbar: {
          show: !1,
        },
      },
      plotOptions: {
        bar: {
          horizontal: !1,
          columnWidth: "45%",
        },
      },
      dataLabels: {
        enabled: !1,
      },
      stroke: {
        show: !0,
        width: 2,
        colors: ["transparent"],
      },
      series: [
        {
          name: "Net Profit",
          data: [46, 57, 59, 54, 62, 58, 64, 60, 66],
        },
        {
          name: "Revenue",
          data: [74, 83, 102, 97, 86, 106, 93, 114, 94],
        },
        {
          name: "Free Cash Flow",
          data: [37, 42, 38, 26, 47, 50, 54, 55, 43],
        },
      ],
      colors: ["#25ACAB", "#3D42AA", "#2D2D2D"],
      xaxis: {
        categories: [
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
        ],
      },
      yaxis: {
        title: {
          text: "$ (thousands)",
          style: {
            fontWeight: "500",
          },
        },
      },
      grid: {
        borderColor: "#f1f1f1",
      },
      fill: {
        opacity: 1,
      },
      tooltip: {
        y: {
          formatter: function (e) {
            return "$ " + e + " thousands";
          },
        },
      },
    };

    var chart = new ApexCharts(
      document.querySelector("#column_chart"),
      options
    );
    chart.render();
  }

  // line,chart
  if ($("#mixedChart").length > 0) {
    var lineColumnAreaColumn = {
      series: [
        {
          name: "TEAM A",
          type: "column",
          data: [23, 11, 22, 27, 13, 22, 37, 21, 44, 22, 30],
        },
        {
          name: "TEAM B",
          type: "area",
          data: [44, 55, 41, 67, 22, 43, 21, 41, 56, 27, 43],
        },
        {
          name: "TEAM C",
          type: "line",
          data: [30, 25, 36, 30, 45, 35, 64, 52, 59, 36, 39],
        },
      ],
      chart: {
        height: 350,
        type: "line",
        stacked: false,
        toolbar: {
          show: !1,
        },
      },
      stroke: {
        width: [0, 2, 5],
        curve: "smooth",
      },
      plotOptions: {
        bar: {
          columnWidth: "50%",
        },
      },

      fill: {
        opacity: [0.85, 0.25, 1],
        gradient: {
          inverseColors: false,
          shade: "light",
          type: "vertical",
          opacityFrom: 0.85,
          opacityTo: 0.55,
          stops: [0, 100, 100, 100],
        },
      },
      labels: [
        "01/01/2003",
        "02/01/2003",
        "03/01/2003",
        "04/01/2003",
        "05/01/2003",
        "06/01/2003",
        "07/01/2003",
        "08/01/2003",
        "09/01/2003",
        "10/01/2003",
        "11/01/2003",
      ],
      markers: {
        size: 0,
      },
      xaxis: {
        type: "datetime",
      },
      yaxis: {
        title: {
          text: "Points",
        },
        min: 0,
      },
      tooltip: {
        shared: true,
        intersect: false,
        y: {
          formatter: function (y) {
            if (typeof y !== "undefined") {
              return y.toFixed(0) + " points";
            }
            return y;
          },
        },
      },
    };

    var chart = new ApexCharts(
      document.querySelector("#mixedChart"),
      lineColumnAreaColumn
    );
    chart.render();
  }

  // radial chart
  if ($("#radialChart").length > 0) {
    var options = {
      series: [44, 55, 67, 83],
      chart: {
        height: 385,
        type: "radialBar",
      },
      plotOptions: {
        radialBar: {
          dataLabels: {
            name: {
              fontSize: "22px",
            },
            value: {
              fontSize: "16px",
            },
            total: {
              show: true,
              label: "Total",
              formatter: function (w) {
                // By default this function returns the average of all series. The below is just an example to show the use of custom formatter function
                return 249;
              },
            },
          },
        },
      },
      labels: ["Apples", "Oranges", "Bananas", "Berries"],
    };

    var chart = new ApexCharts(document.querySelector("#radialChart"), options);
    chart.render();
  }

  //  column
  if ($("#column_chart_datalabel").length > 0) {
    var options = {
      chart: {
        height: 350,
        type: "bar",
        toolbar: {
          show: !1,
        },
      },
      plotOptions: {
        bar: {
          borderRadius: 10,
          dataLabels: {
            position: "top",
          },
        },
      },
      dataLabels: {
        enabled: !0,
        formatter: function (e) {
          return e + "%";
        },
        offsetY: -22,
        style: {
          fontSize: "12px",
          colors: ["#304758"],
        },
      },
      series: [
        {
          name: "Inflation",
          data: [2.5, 3.2, 5, 10.1, 4.2, 3.8, 3, 2.4, 4, 1.2, 3.5, 0.8],
        },
      ],
      colors: ["#25ACAB"],
      grid: {
        borderColor: "#f1f1f1",
      },
      xaxis: {
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Dec",
        ],
        position: "top",
        labels: {
          offsetY: -18,
        },
        axisBorder: {
          show: !1,
        },
        axisTicks: {
          show: !1,
        },
        crosshairs: {
          fill: {
            type: "gradient",
            gradient: {
              colorFrom: "#D8E3F0",
              colorTo: "#BED1E6",
              stops: [0, 100],
              opacityFrom: 0.4,
              opacityTo: 0.5,
            },
          },
        },
        tooltip: {
          enabled: !0,
          offsetY: -35,
        },
      },
      yaxis: {
        axisBorder: {
          show: !1,
        },
        axisTicks: {
          show: !1,
        },
        labels: {
          show: !1,
          formatter: function (e) {
            return e + "%";
          },
        },
      },
    };
    var chart = new ApexCharts(
      document.querySelector("#column_chart_datalabel"),
      options
    ).render();
  }

  // basic bar Chart
  if ($("#bar_chart").length > 0) {
    var options = {
      series: [
        {
          data: [400, 430, 448, 470, 540, 580, 690, 1100, 1200, 1380],
        },
      ],
      chart: {
        type: "bar",
        height: 350,
        toolbar: {
          show: !1,
        },
      },

      plotOptions: {
        bar: {
          borderRadius: 4,
          horizontal: true,
          color: ["#3D42AA"],
        },
      },
      dataLabels: {
        enabled: false,
      },
      xaxis: {
        categories: [
          "South Korea",
          "Canada",
          "United Kingdom",
          "Netherlands",
          "Italy",
          "France",
          "Japan",
          "United States",
          "China",
          "Germany",
        ],
      },
    };

    var chart = new ApexCharts(document.querySelector("#bar_chart"), options);
    chart.render();
  }
})(jQuery);
