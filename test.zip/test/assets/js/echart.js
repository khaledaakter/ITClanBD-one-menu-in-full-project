!(function ($) {
  // line chart
  if ($("#line-chart").length > 0) {
    var dom = document.getElementById("line-chart");
    var icLineChart = echarts.init(dom);
    var app = {};
    var option;
    option = {
      xAxis: {
        type: "category",
        data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        axisLine: {
          lineStyle: {
            color: "#858d98",
          },
        },
      },
      toolbox: {
        orient: "right",
        right: 0,
        top: 0,
        feature: {
          dataView: {
            readOnly: !1,
            title: "Data View",
          },
          magicType: {
            type: ["line", "bar"],
            title: {
              line: "For line chart",
              bar: "For bar chart",
            },
          },
          restore: {
            title: "restore",
          },
          saveAsImage: {
            title: "Download Image",
          },
        },
      },
      yAxis: {
        type: "value",
        axisLine: {
          lineStyle: {
            color: "#858d98",
          },
        },
        splitLine: {
          lineStyle: {
            color: "rgba(133, 141, 152, 0.1)",
          },
        },
      },
      series: [
        {
          data: [820, 932, 901, 934, 1290, 1330, 1320],
          type: "line",
          smooth: true,
        },
      ],
    };

    if (option && typeof option === "object") {
      icLineChart.setOption(option);
    }
  }

  // bar chart
  if ($("#bar-chart").length > 0) {
    var chartDom = document.getElementById("bar-chart");
    var icBarChart = echarts.init(chartDom);
    var option;

    option = {
      xAxis: {
        type: "category",
        data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        axisLine: {
          lineStyle: {
            color: "#858d98",
          },
        },
      },
      yAxis: {
        type: "value",
        axisLine: {
          lineStyle: {
            color: "#858d98",
          },
        },
        splitLine: {
          lineStyle: {
            color: "rgba(133, 141, 152, 0.1)",
          },
        },
      },
      series: [
        {
          data: [120, 200, 150, 80, 70, 110, 130],
          type: "bar",
        },
      ],
    };

    option && icBarChart.setOption(option);
  }

  //  doughnut chart
  if ($("#doughnut-chart").length > 0) {
    var dom = document.getElementById("doughnut-chart");
    var icDougHunt = echarts.init(dom);
    var app = {};

    var option;
    option = {
      tooltip: {
        trigger: "item",
      },
      color: ["#25ACAB", "#3D42AA", "#2D2D2D", "#FFBF2E", "#FF5C66"],
      legend: {
        orient: "vertical",
        top: "5%",
        right: "right",
        show: false,
      },
      series: [
        {
          name: "Access From",
          type: "pie",
          radius: ["40%", "70%"],
          avoidLabelOverlap: false,
          label: {
            show: false,
            position: "center",
          },
          emphasis: {
            label: {
              show: true,
              fontSize: "16",
              fontWeight: "bold",
            },
          },
          labelLine: {
            show: false,
          },
          data: [
            { value: 1048, name: "Tax & vat" },
            { value: 735, name: "Direct" },
            { value: 580, name: "Email" },
            { value: 484, name: "Union Ads" },
            { value: 300, name: "Video Ads" },
          ],
        },
      ],
    };

    if (option && typeof option === "object") {
      icDougHunt.setOption(option);
    }
  }

  // pie chart

  if ($("#pie-chart").length > 0) {
    var icPie = document.getElementById("pie-chart");
    var icPieChart = echarts.init(icPie);
    var app = {};
    var option;
    option = {
      tooltip: {
        trigger: "item",
      },
      legend: {
        orient: "vertical",
        left: "left",
      },
      series: [
        {
          name: "Access From",
          type: "pie",
          radius: "50%",
          data: [
            { value: 1048, name: "Search Engine" },
            { value: 735, name: "Direct sani" },
            { value: 580, name: "Email" },
            { value: 484, name: "Union Ads" },
            { value: 300, name: "Video Ads" },
          ],
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: "rgba(0, 0, 0, 0.5)",
            },
          },
        },
      ],
    };

    if (option && typeof option === "object") {
      icPieChart.setOption(option);
    }
  }
})(jQuery);
