// jquery konb

$(function () { $(".knob").knob() });