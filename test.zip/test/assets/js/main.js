/*===============================================

Theme Name:Clan Dash  Admin Template
Version:1.0
Author: ITCLAN
Support: itclan@gmail.com
Description: Clan Dash  Admin Template

NOTE:
=====
Please DO NOT EDIT THIS JS, you may need to use "custom.js".

===============================================**/

(function ($) {
  ("use strict");

  /*========================================
        Tooltips
    ========================================*/
  var tooltipTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="tooltip"]')
  );
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
  /*========================================
        popover
    ========================================*/
  var popoverTriggerList = [].slice.call(
    document.querySelectorAll('[data-bs-toggle="popover"]')
  );
  var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl);
  });

  /*========================================
        color picker
    ========================================*/
  // $('#cp2').colorpicker();

  /*========================================
        Preloader
    ========================================*/

  $(window).on("load", function () {
    $("#loading").fadeOut(500);
  });

  // $(".main-sidebar").niceScroll();

  /*========================================
        Toggle Fullscreen
    ========================================*/

  function toggleFullscreen(elem) {
    elem = elem || document.documentElement;
    if (
      !document.fullscreenElement &&
      !document.mozFullScreenElement &&
      !document.webkitFullscreenElement &&
      !document.msFullscreenElement
    ) {
      if (elem.requestFullscreen) {
        elem.requestFullscreen();
      } else if (elem.msRequestFullscreen) {
        elem.msRequestFullscreen();
      } else if (elem.mozRequestFullScreen) {
        elem.mozRequestFullScreen();
      } else if (elem.webkitRequestFullscreen) {
        elem.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      }
    }
  }

  $("#btnFullscreen").on("click", function () {
    toggleFullscreen();
  });

  /*========================================
        Sidebar Toggle
    ========================================*/

  if ($(window).width() < 1200) {
    $("body").addClass("ic-mini-sidebar");
  }
  $(".ic-nav-collapse").on("click", function () {
    $("body").addClass("ic-mini-sidebar");
    $(this).hide();
    $(".ic-sidebar-cancel").show();
  });
  $(".ic-sidebar-cancel").on("click", function () {
    $("body").removeClass("ic-mini-sidebar");
    $(this).hide();
    $(".ic-nav-collapse").show();
  });
  $(".ic-mobile-nav-collapse").on("click", function () {
    $("body").removeClass("ic-mini-sidebar");
    $(".ic-mobile-sidebar-close").show();
  });
  $(".ic-mobile-sidebar-close").on("click", function () {
    $("body").addClass("ic-mini-sidebar");
    $(this).hide();
  });

  /*========================================
        Menu itemToggle
    ========================================*/

  var $icMaineNavbar = $(".ic-navbar-nav"),
    $icSubMenuNav = $icMaineNavbar.find(".ic-dropdown-sub-menu");
  $icSubMenuNav.slideUp();
  $icMaineNavbar.on("click", "li a, li .menu-expand", function (e) {
    var $this = $(this);
    if (
      $this
        .parent()
        .attr("class")
        .match(
          /\b(ic-menu-item-has-children|has-children|has-ic_sub_menu)\b/
        ) &&
      ($this.attr("href") === "#" || $this.hasClass("menu-expand"))
    ) {
      e.preventDefault();
      if ($this.siblings("ul:visible").length) {
        $this.siblings("ul").slideUp("slow");
      } else {
        $this.closest("li").siblings("li").find("ul:visible").slideUp("slow");
        $this.siblings("ul").slideDown("slow");
      }
    }
    if (
      $this.is("a") ||
      $this.is("span") ||
      $this.attr("clas").match(/\b(menu-expand)\b/)
    ) {
      $this.parent().toggleClass("menu-open");
    } else if (
      $this.is("li") &&
      $this.attr("class").match(/\b('ic-menu-item-has-children')\b/)
    ) {
      $this.toggleClass("menu-open");
    }
  });

  /*========================================
        Carousel
    ========================================*/
  $(".ic-slide-only").slick({
    dots: false,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 2500,
  });

  //Slider With Control

  $(".ic-slide-controls").slick({
    dots: false,
    arrows: true,
    autoplay: true,
    autoplaySpeed: 2500,
  });

  //Slider With Indicators

  $(".ic-slide-indicators").slick({
    dots: true,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 2500,
  });
  //Slider With Caption

  $(".ic-slider-with-caption").slick({
    dots: false,
    arrows: true,
    autoplay: true,
    autoplaySpeed: 2500,
  });

  //Slider With Thumbnil

  $(".ic-slider-thumbnil-main").slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
    asNavFor: ".ic-slider-thumbnil",
    dots: false,
  });
  $(".ic-slider-thumbnil").slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    asNavFor: ".ic-slider-thumbnil-main",
    dots: false,
    focusOnSelect: true,
  });

  $(function () {
    var start = moment().subtract(29, "days");
    var end = moment();

    function cb(start, end) {
      $("#reportrange span").html(
        start.format("D MMMM, YYYY") + " - " + end.format("D MMMM, YYYY")
      );
    }

    $("#reportrange").daterangepicker(
      {
        startDate: start,
        endDate: end,
        ranges: {
          Today: [moment(), moment()],
          Yesterday: [
            moment().subtract(1, "days"),
            moment().subtract(1, "days"),
          ],
          "Last 7 Days": [moment().subtract(6, "days"), moment()],
          "Last 30 Days": [moment().subtract(29, "days"), moment()],
          "This Month": [moment().startOf("month"), moment().endOf("month")],
          "Last Month": [
            moment().subtract(1, "month").startOf("month"),
            moment().subtract(1, "month").endOf("month"),
          ],
        },
      },
      cb
    );

    cb(start, end);
  });
  /*========================================
        Email Check All
    ========================================*/

  $("#flexCheckDefault").on("click", function () {
    $(".check-email").prop("checked", $(this).prop("checked"));
    $(".check-flexDefault").prop("checked", $(this).prop("checked"));
    $(".check-dropAll").prop("checked", $(this).prop("checked"));
  });

  $("#checkDropdownAll").on("click", function () {
    $(".check-email").prop("checked", $(this).prop("checked"));
    $(".check-flexDefault").prop("checked", $(this).prop("checked"));
    $(".check-dropAll").prop("checked", $(this).prop("checked"));
  });

  $(".check-email").on("click", function () {
    let childEmailNum = $(".check-email").length;

    let checkedItems = 0;
    $(".check-email").each(function () {
      if ($(this).prop("checked")) {
        checkedItems++;
      }
    });

    if (checkedItems < childEmailNum) {
      $(".check-flexDefault").prop("checked", false);
      $(".check-dropAll").prop("checked", false);
    } else {
      $(".check-flexDefault").prop("checked", true);
      $(".check-dropAll").prop("checked", true);
    }
  });

  // ------------ starred email -----------

  $(".ic-email-star").on("click", function () {
    $(this).toggleClass("ri-star-line ");
    $(this).toggleClass("ri-star-fill ic-starred");
  });

  // ----------- Summernote ------------

  $("#summernote").summernote({
    placeholder: "Write Message Here",
    tabsize: 2,
    height: 120,
    toolbar: [
      ["style", ["style"]],
      ["font", ["bold", "underline", "clear"]],
      ["color", ["color"]],
      ["para", ["ul", "ol", "paragraph"]],
      ["table", ["table"]],
      ["insert", ["link", "picture"]],
      ["view", ["codeview", "help"]],
    ],
  });

  //------------- Form validation --------------

  var forms = document.querySelectorAll(".ic-form-validation");
  // Loop over them and prevent submission
  Array.prototype.slice.call(forms).forEach(function (form) {
    form.addEventListener(
      "submit",
      function (event) {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }

        form.classList.add("was-validated");
      },
      false
    );
  });

  //------------ Form Step Progress bar -------------
  // basic wizard
  $(document).ready(function () {
    var currentGfgStep, nextGfgStep, previousGfgStep;
    var opacity;

    $(".next-step").click(function () {
      currentGfgStep = $(this).parent();
      nextGfgStep = $(this).parent().next();

      $(".progressbar li")
        .eq($("fieldset").index(nextGfgStep))
        .addClass("active");

      $(".progressbar code")
        .eq($("fieldset").index(nextGfgStep))
        .addClass("active");

      nextGfgStep.show();
      currentGfgStep.animate(
        { opacity: 0 },
        {
          step: function (now) {
            opacity = 1 - now;

            currentGfgStep.css({
              display: "none",
              position: "relative",
            });
            nextGfgStep.css({ opacity: opacity });
          },
          duration: 500,
        }
      );
    });

    $(".previous-step").click(function () {
      currentGfgStep = $(this).parent();
      previousGfgStep = $(this).parent().prev();

      $(".progressbar li")
        .eq($("fieldset").index(currentGfgStep))
        .removeClass("active");

      $(".progressbar code")
        .eq($("fieldset").index(currentGfgStep))
        .removeClass("active");

      previousGfgStep.show();

      currentGfgStep.animate(
        { opacity: 0 },
        {
          step: function (now) {
            opacity = 1 - now;

            currentGfgStep.css({
              display: "none",
              position: "relative",
            });
            previousGfgStep.css({ opacity: opacity });
          },
          duration: 500,
        }
      );
    });

    $(".submit").click(function () {
      return false;
    });
  });

  //--- horizontal wizard
  $(document).ready(function () {
    var currentGfgStep, nextGfgStep, previousGfgStep;
    var opacity;

    $(".h-next-step").click(function () {
      currentGfgStep = $(this).parent();
      nextGfgStep = $(this).parent().next();

      $(".hori_Progressbar li")
        .eq($(".h-fieldset").index(nextGfgStep))
        .addClass("active");

      nextGfgStep.show();
      currentGfgStep.animate(
        { opacity: 0 },
        {
          step: function (now) {
            opacity = 1 - now;

            currentGfgStep.css({
              display: "none",
              position: "relative",
            });
            nextGfgStep.css({ opacity: opacity });
          },
          duration: 500,
        }
      );
    });

    $(".h-previous-step").click(function () {
      currentGfgStep = $(this).parent();
      previousGfgStep = $(this).parent().prev();

      $(".hori_Progressbar li")
        .eq($(".h-fieldset").index(currentGfgStep))
        .removeClass("active");

      previousGfgStep.show();

      currentGfgStep.animate(
        { opacity: 0 },
        {
          step: function (now) {
            opacity = 1 - now;

            currentGfgStep.css({
              display: "none",
              position: "relative",
            });
            previousGfgStep.css({ opacity: opacity });
          },
          duration: 500,
        }
      );
    });

    $(".submit").click(function () {
      return false;
    });
  });

  // -- Advance wizard validation
  $(document).ready(function () {
    var currentGfgStep, nextGfgStep, previousGfgStep;
    var opacity;

    let bool = false;

    var forms = document.querySelectorAll(".advance-wizard-form");
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms).forEach(function (form) {
      form.addEventListener(
        "submit",
        function (event) {
          if (!form.checkValidity()) {
            event.preventDefault();
            // event.stopPropagation();

            // bool = false;
          } else {
            // $(".a-next-step").trigger("click");
            // $(".a-next-step").click();
            // bool = true;
          }
          form.classList.add("was-validated");
        },
        false
      );
    });

    // ---------------------

    $(".a-next-step").click(function () {
      if (bool) {
        currentGfgStep = $(this).parent();
        nextGfgStep = $(this).parent().next();

        $(".a-progressbar li")
          .eq($(".a-fieldset").index(nextGfgStep))
          .addClass("active");

        nextGfgStep.show();
        currentGfgStep.animate(
          { opacity: 0 },
          {
            step: function (now) {
              opacity = 1 - now;

              currentGfgStep.css({
                display: "none",
                position: "relative",
              });
              nextGfgStep.css({ opacity: opacity });
            },
            duration: 500,
          }
        );
      }
    });

    $(".a-previous-step").click(function () {
      currentGfgStep = $(this).parent();
      previousGfgStep = $(this).parent().prev();

      $(".a-progressbar li")
        .eq($(".a-fieldset").index(currentGfgStep))
        .removeClass("active");

      previousGfgStep.show();

      currentGfgStep.animate(
        { opacity: 0 },
        {
          step: function (now) {
            opacity = 1 - now;

            currentGfgStep.css({
              display: "none",
              position: "relative",
            });
            previousGfgStep.css({ opacity: opacity });
          },
          duration: 500,
        }
      );
    });

    $(".submit").click(function () {
      return false;
    });
  });

  // //-- Advance wizard validation
  // $("#account-form").validate({
  //   rules: {
  //     confirm: {
  //       equalTo: "#password",
  //     },
  //   },
  // });
  // $("#profile-form").validate();
  // $("#form-1").validate();
  // $("#jquery-steps").steps({
  //   headerTag: "h3",
  //   bodyTag: "section",
  //   transitionEffect: "slideLeft",
  //   onStepChanging: function (event, currentIndex, newIndex) {
  //     if (newIndex < currentIndex) {
  //       return true;
  //     }
  //     var form = $(".body.current form");
  //     if (form.length == 1) {
  //       form.validate().settings.ignore = ":disabled,:hidden";
  //       return form.valid();
  //     }
  //     return true;
  //   },
  //   onFinishing: function (event, currentIndex) {
  //     var form = $(".body.current form");
  //     if (form.length == 1) {
  //       form.validate().settings.ignore = ":disabled";
  //       return form.valid();
  //     }
  //     return true;
  //   },
  //   onFinished: function (event, currentIndex) {
  //     alert("Submitted!");
  //   },
  // });

  /**Jquery End **/
})(jQuery);
